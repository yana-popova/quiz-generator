#include<iostream>
#include<fstream>
#include<string.h>
#include<string>
#include"ManyAnswers.h"
#include"PatternValidation.h"
using namespace std;
string* ManyAnswers::getOptions() const{
	return options;
}
void ManyAnswers::setCorrectAnswers(string correctAnswers){
	this->correctAnswers = correctAnswers;
}
string ManyAnswers::getCorrectAnswers() const{
	return correctAnswers;
}
void ManyAnswers::setSizeOptions(int o){
	sizeOptions = o;
}
int ManyAnswers::getSizeOptions() const{
	return sizeOptions;
}
ManyAnswers::ManyAnswers(){
	setCategory("default c");
	setProblem("default p");
	options = new string[5];
	setCorrectAnswers("A");
	setScore(15);
	setType(3);
	setSizeOptions(5);
}
ManyAnswers::ManyAnswers(string* options, string correctAnswers, int sizeOptions, string category, string problem, int type, int score) : Question(problem, category, type, score) {
	setSizeOptions(sizeOptions);
	this->options = new string[sizeOptions];
	setCorrectAnswers(correctAnswers);
}
ManyAnswers::~ManyAnswers(){
	delete[] options;
}
void ManyAnswers::readFromFile(ifstream& reader){
	//the pattern: type, category, sizeOptions, options**, correctAnswers, score  
	setType(3);
	string text;
	getline(reader, text);
	setCategory(text);
	getline(reader, text);
	setProblem(text);
	int s;
	reader >> s;
	setSizeOptions(s);
	reader.ignore();
	options = new string[s];
	for (int i = 0; i < sizeOptions; i++){
		getline(reader, text);
		options[i] = text;
	}
	getline(reader, text);
	setCorrectAnswers(text);
	int y;
	reader >> y;
	setScore(y);
	reader.ignore(); //posle shte chete string za tipa na vuprosa 
}
void ManyAnswers::writeToFileForTeachers(string filename, bool wantAnAnswer, bool file){
	ofstream writer;
	writer.open(filename, ios::app);
	if (file == 1){
		writer << getType() << endl << getCategory() << endl;
	}
	writer << getProblem() << endl;
	if (file == 1) writer << sizeOptions << endl;
	for (int i = 0; i < sizeOptions; i++){
		writer << options[i] << endl;
	}
	if (file == 1){
		writer << correctAnswers << endl << getScore() << endl;
	}
	else {
		if (wantAnAnswer == true) writer << "Answers: " << correctAnswers << endl;
		else writer << "Answers:_______________" << endl;
		writer << getScore() << " points" << endl << endl;
	}
	writer.close();
}
string ManyAnswers::createAQuestion(string enteredText, int& questionSlide){
	string a;
	questionSlide++;
	if (questionSlide == 0 || questionSlide == 1 || questionSlide==2){
		a=createBasicQuestion(enteredText, questionSlide);  
		return a;
	}
	else if (questionSlide == 3){
		bool validAnswers = PatternValidation::validMultipleChoiceAnswerFromat(enteredText);
		if (validAnswers == 0){
			questionSlide--;
			a = "Invalid format. Try again.";
		}
		else {
			setCorrectAnswers(enteredText);
			a = "Number of options:";
		}
		return a;
	}
	else if (questionSlide == 4){
		sizeOptions = stoi(enteredText);
		options = new string[sizeOptions];
		a = "Option (you do not have to write the\nletter of the option):";
		return a;
	}
	else {
		for (int i = 5; i < sizeOptions + 5; i++){ 
			if (i == sizeOptions + 4 && questionSlide == i){
				enteredText[0] = toupper(enteredText[0]);
				a = "Press enter to submit the question,\nplease.";
				enteredText = +". " + enteredText;
				options[i - 5] = (char)(65 + i - 5) + enteredText;
			}
			else if (questionSlide == i){
				enteredText[0] = toupper(enteredText[0]);
			    a = "Option:";
				enteredText = +". " + enteredText;
				options[i - 5] = (char)(65 + i - 5) + enteredText;
			}
		}
		return a;
	}
}
