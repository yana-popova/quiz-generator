#include <SFML/Graphics.hpp>
#include <iostream>
#include <windows.h>
#include <string.h>
#include <string>
#include "Question.h"
#include "MultipleChoice.h"
#include "ManyAnswers.h"
#include "OpenEndedQuestion.h"
#include "QuestionArray.h"
#include "PatternValidation.h"
using namespace std;
void settingAnImage(sf::Image& background, sf::Texture& texture, sf::Sprite& sprite, const char* imageName){
	if (!background.loadFromFile(imageName)) return;  //check whether this file can be loaded
	if (!texture.loadFromImage(background)) return;  //check whether the texture can load the background (the texture is an image)
	texture.setSmooth(true);  //smoothing the picture - we change the way it's rendered
	sprite.setTexture(texture); // we create the sprite and call the texture
}
void settingAText(sf::Font& font, const char* fontName, sf::Text& text, const char* whatToWrite, const unsigned int sizeOfCharacters, const float posX, const float posY, const sf::Color color, unsigned int style){
	if (!font.loadFromFile(fontName)) return; //we load the font
	text.setFont(font);
	text.setString(whatToWrite);
	text.setCharacterSize(sizeOfCharacters);
	text.setPosition(posX, posY);
	text.setColor(color);
	text.setStyle(style);
}
void personalizeARectangle(sf::RectangleShape& rectangle, const sf::Vector2f sizeVector, const sf::Color color, const float outline, const float posX, const float posY){
	rectangle.setSize(sizeVector);
	rectangle.setOutlineColor(color);
	rectangle.setOutlineThickness(outline);
	rectangle.setPosition(posX, posY);
}
bool isAreaClicked(int figurePosX, int figurePosY, int sizeX, int sizeY, sf::Window& window){
	int mouseX = sf::Mouse::getPosition(window).x;
	int mouseY = sf::Mouse::getPosition(window).y;
	return mouseX >= figurePosX && mouseX <= figurePosX + sizeX && mouseY >= figurePosY && mouseY <= figurePosY + sizeY && sf::Mouse::isButtonPressed(sf::Mouse::Left);
}
void main()
{
	sf::RenderWindow window(sf::VideoMode(900, 600), "Quiz!", sf::Style::Default); //we create the window
	//START PAGE background
	sf::Image backgroundSP;
	sf::Texture textureSP;
	sf::Sprite spriteSP;
	settingAnImage(backgroundSP, textureSP, spriteSP, "first.jpg");
	spriteSP.scale(sf::Vector2f(0.25f, 0.25f)); // factor relative to the current scale - an alternative to resizing the image in Paint
	//we create and position the texts
	sf::Font font;
	sf::Text textQuizGenerator, textStart, enteredString, programLine, OK; //enteredString - the user input; programLine - what the programme says
	settingAText(font, "arial.ttf", textQuizGenerator, "QUIZ GENERATOR", 30, 350, 50, sf::Color::Red, sf::Text::Bold);
	settingAText(font, "arial.ttf", textStart, "START", 25, 95, 373, sf::Color::Red, sf::Text::Bold);
	settingAText(font, "arial.ttf", enteredString, "", 25, 210, 373, sf::Color::Red, sf::Text::Bold);
	settingAText(font, "arial.ttf", programLine, "Which file (.txt) would you like to read\nfrom? ", 30, 160, 150, sf::Color::Red, sf::Text::Bold);
	settingAText(font, "arial.ttf", OK, "OK", 50, 400, 363, sf::Color::Red, sf::Text::Bold);
	//backgrounds of pages other than the start one
	sf::Image backgroundOP;
	sf::Texture textureOP;
	sf::Sprite spriteOP;
	settingAnImage(backgroundOP, textureOP, spriteOP, "paper.jpg"); //other pages
	spriteOP.scale(sf::Vector2f(1.15f, 1.0f));
	sf::Image backgroundEP;
	sf::Texture textureEP;
	sf::Sprite spriteEP;
	settingAnImage(backgroundEP, textureEP, spriteEP, "lastPage.jpg"); //last page
	spriteEP.scale(sf::Vector2f(2.0f, 2.0f));

	//in order to call the personalise array function:
	bool exists = true; //whether the file which we will read form exits
	bool validFile = true; //whether the file ends with .txt
	bool validCateg = true; //whether the category starts with a capital letter
	bool validNumber = true;//whether the input is a whole positive number
	int currentSlide = 0;
	string fileR, fileW, cat;
	int top = 0, bottom = 0, questions = 0;
	int noQuestions = 0;
	bool answers = false;
	bool file = false;
	QuestionArray a;

	sf::RectangleShape question, answer;
	personalizeARectangle(question, sf::Vector2f(600, 200), sf::Color::Black, 5, 145, 85);
	personalizeARectangle(answer, sf::Vector2f(500, 100), sf::Color::Black, 5, 195, 345);

	string enteredText;
	//variables for adding a question
	bool add = true;
	int createSlide = -1;
	int questionSlide = -1;
	int qType = 0;
	Question* q = nullptr;
	string fileToAdd;
	bool category = 0;
	while (window.isOpen()) //without this loop the window is irresponsive
	{
		sf::Event event;
		while (window.pollEvent(event))
		{
			if (event.type == sf::Event::Closed) window.close();
			if (currentSlide == 10 && sf::Mouse::isButtonPressed(sf::Mouse::Left) || sf::Mouse::isButtonPressed(sf::Mouse::Right)) {
				window.close();
			}
			if (event.type == sf::Event::TextEntered){
				if (currentSlide == 10) window.close();
   				if (event.text.unicode == 13){ //enter
					enteredString.setPosition(sf::Vector2f(210, 373));
					answer.setSize(sf::Vector2f(500, 100));
					enteredText.erase(std::remove(enteredText.begin(), enteredText.end(), '\n'), enteredText.end());
					enteredText[enteredText.size()] = '\n';
					switch (currentSlide){
					case 1:
						fileR = enteredText;
						exists = PatternValidation::doesTheFileExist(fileR);
						validFile = PatternValidation::validFileFormat(fileR);
						programLine.setString("How many questions would you like the \nquiz to have?");
						if (exists == 0) {
							programLine.setString("This file does not exist.\nTry again:");
							currentSlide--;
							exists = 1;
						}
						if (validFile == 0){
							if (PatternValidation::doesTheFileExist(fileR) == 1) currentSlide--;
							programLine.setString("Invalid file format.\nTry again:");
							validFile = 1;
						}
						break;
					case 2:
						validNumber = PatternValidation::validNumber(enteredText);
						programLine.setString("Enter the minimum value of difficulty,\nplease: ");
						if (validNumber == 0) {
							programLine.setString("Invalid format. You should enter\na natural number. Try again:");
							currentSlide--;
							validNumber = 1;
						}
						else questions = stoi(enteredText);
						break;
					case 3:
						validNumber = PatternValidation::validNumber(enteredText);
						programLine.setString("Enter the maximum value of difficulty,\nplease: ");
						if (validNumber == 0) {
							programLine.setString("Invalid format. You should enter\na natural number. Try again:");
							currentSlide--;
							validNumber = 1;
						}
						else bottom = stoi(enteredText);
						break;
					case 4:
						validNumber = PatternValidation::validNumber(enteredText);
						programLine.setString("Enter the category: (start with a capital\nletter, please)");
						if (validNumber == 0) {
							programLine.setString("Invalid format. You should enter\na natural number. Try again:");
							currentSlide--;
							validNumber = 1;
						}
						else top = stoi(enteredText);
						break;
					case 5:
						cat = enteredText;
						programLine.setString("Which file (.txt) should the questions be \nwritten to? ");
						validCateg = PatternValidation::validCategoryFormat(cat);
						if (validCateg == 0) {
							programLine.setString("Invalid format.\nTry again:");
							currentSlide--;
							validCateg = 1;
						}
						break;
					case 6:
						fileW = enteredText;
						programLine.setString("Would you like to have the answers \nwritten? 1 - Yes / 0 - No ");
						validFile = PatternValidation::validFileFormat(fileW);
						if (validFile == 0){
						    currentSlide--;
							programLine.setString("Invalid file format.\nTry again:");
							validFile = 1;
						}
						break;
					case 7:
						programLine.setString("Would you like to add a question?\n1 - Yes / 0 - No");
						if (stoi(enteredText) == 0) answers = false;
						else answers = true;
						noQuestions = a.personaliseQuestionArray(fileR, questions, bottom, top, cat, fileW, answers, file); //this line is here so that it is executed only once
						if (noQuestions == 0){
							programLine.setString("There are not enough questions that \nmatch your requirements in the\nfile you entered.");
							programLine.setPosition(sf::Vector2f(160, 140));
						}
						else if (noQuestions == 1){
							programLine.setString("There are no questions that match your \nreqirements in the file you entered.");
						}
						else{
							currentSlide++;
						}
						break;
					case 9:
						switch (createSlide){
						case -1:
							questionSlide = -1;
							if (stoi(enteredText) == 0) add = false;
							else add = true;
							if (add == 0) currentSlide++; //break the case 9 switch by making currentSlide=10
							else{
								programLine.setString("Will this question be added to a quiz or\nto a file that you will read from in the\nfuture? 1 - quiz / 2 - file");
								programLine.setPosition(160, 120);
							}
							break;
						case 0:
							if (stoi(enteredText) == 1) file = false;
							else file = true;
							programLine.setString("Which type of question would you like to \ncreate ? \n1 - Multiple Choice\n2 - Open - ended\n3 - With many answers");
							programLine.setPosition(160, 100);
							break;
						case 1:
							qType = stoi(enteredText);
							delete q;
							q = nullptr;
							switch (qType){
							case 1:
								q = new MultipleChoice();
								break;
							case 2:
								q = new OpenEndedQuestion();
								break;
							case 3:
								q = new ManyAnswers();
								break;
							}
							q->setType(qType);
							programLine.setString("Which file (.txt) would you like to write \nyour question to?");
							programLine.setPosition(160, 150);
							break;
						case 2:
							fileToAdd = enteredText;
						    programLine.setString("Would you like to have the answers \nwritten? 1 - Yes / 0 - No ");
							validFile = PatternValidation::validFileFormat(fileToAdd);
							if (validFile == 0){
								createSlide--;
								programLine.setString("Invalid file format.\nTry again:");
								validFile = 1;
							}
							break;
						case 3:
							if (stoi(enteredText) == 0) answers = false;
							else answers = true;
							programLine.setString("Category: ");
							break;
						case 4:
							programLine.setString(q->createAQuestion(enteredText, questionSlide));
							//=>dava s 1 napred-ako izliza Categ, ti si go vuvel veche - tova e zaradi enter - zatova davame gore Category
							createSlide--;
							break;
						}
						currentSlide--;
						createSlide++; //the last line of the createQuestion function is createSlide=-1 and here it will become 0. Then the the whole create-question option starts again
						break;
					}
					enteredText.clear();
					enteredString.setString(enteredText);
					currentSlide++;
				}
				if (event.text.unicode == '\b'){ //backspace 
					if (enteredText.size() != 0) enteredText.erase(enteredText.size() - 1, 1);
					enteredString.setString(enteredText);
				}
				else if (event.text.unicode < 128 && event.text.unicode != 13){
					enteredText.push_back((char)event.text.unicode);
					enteredString.setString(enteredText);
				}
			}
		}
		window.clear();
		if (currentSlide == 0){
			window.draw(spriteSP);
			window.draw(textQuizGenerator);
			window.draw(textStart);
			bool clicked = isAreaClicked(90, 340, 100, 100, window); //if it's not fullscreen
			if (clicked == true) currentSlide++;
		}
		else {
			if (enteredText.size() == 35){
				enteredText.insert(35, "\n"); //size e 35, poslednoto e na poziciq 34 i zatova slagame 35
				enteredString.setPosition(sf::Vector2f(210, 363));
			}
			if (enteredText.size() == 70){
				enteredText.insert(70, "\n");
				enteredString.setPosition(sf::Vector2f(210, 353));
			}
			if (enteredText.size() == 105){
				enteredText.insert(105, "\n");
				answer.setSize(sf::Vector2f(500, 150));
			}
			if (enteredText.size() == 140){
				enteredText.insert(140, "\n");
			}
			window.draw(spriteOP); //first we set the elements that are not text
			window.draw(question);
			window.draw(answer);
			if (currentSlide != 8) window.draw(enteredString); //drawing the input text
			if (currentSlide != 10) window.draw(programLine);
			if (currentSlide == 8) {
				if (noQuestions != 2) window.draw(OK);
				if (isAreaClicked(190, 340, 500, 100, window) == true){
					currentSlide++;
					programLine.setString("Would you like to add a question?\n1 - Yes / 0 - No");
					window.draw(programLine);
				}
			}
			if (currentSlide == 9 && createSlide == 4) {
				string a = programLine.getString();
				string b = "Press enter to submit the question,\nplease.";
				if ((qType == 1 && questionSlide == 7) || (qType == 2 && questionSlide == 3) || (qType == 3 && a == b)){
					createSlide = -1;
					q->writeToFileForTeachers(fileToAdd, answers, file);
					programLine.setString("Would you like to add a question?\n1 - Yes / 0 - No");
				}
			}
			if (currentSlide == 10) window.draw(spriteEP);
		}
		window.display();
	}
}
//!!! When there is an "Unresolved externals" error, you have not implemented a function that you have declared.
//!!! When there is a "Buffer too small" error, you haven't allocated enough memory-usually in strcpy_s.
//!!! When there is an "Access reading location violation" error, you haven't allocated memory for sth.