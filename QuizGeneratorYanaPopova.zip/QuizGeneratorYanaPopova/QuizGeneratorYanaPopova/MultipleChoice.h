#pragma once
#include"Question.h"
#include<string.h>
using namespace std;
class MultipleChoice : public Question{
private:
	string answerA;
	string answerB;
	string answerC;
	string answerD;
	char rightAnswer;
public:
	void setAnswerA(string); //mai ne mi trqbvat set i get
	void setAnswerB(string);
	void setAnswerC(string);
	void setAnswerD(string);
	void setRightAnswer(char);
	string getAnswerA() const;
	string getAnswerB() const;
	string getAnswerC() const;
	string getAnswerD() const;
	char getRightAnswer() const;
	MultipleChoice();
	MultipleChoice(string, string, string, string, char, string, string, int, int); //we need this for the default constructor
	MultipleChoice(const MultipleChoice&);
	~MultipleChoice();

	void readFromFile(ifstream&);
	void writeToFileForTeachers(string, bool, bool);
	string createAQuestion(string, int&);
};