#include<iostream>
#include<fstream>
#include<string.h>
#include<string>
#include"PatternValidation.h"
#include"QuestionArray.h"
#include<windows.h>
#include<stdlib.h>
#include<time.h>
using namespace std;
QuestionArray::QuestionArray(){
	questions = new Question*[1];
	size = 1;
	questions[0] = nullptr;
}
QuestionArray::~QuestionArray(){
	for (int i = 0; i < currentSize; i++){
		delete questions[i];
	}
	delete[] questions;
}
void QuestionArray::setSize(int s){
	size = s;
}
int QuestionArray::getSize() const{
	return size;
}
void QuestionArray::setCurrentSize(int s){
	currentSize = s;
}
Question** QuestionArray::getQuestions() const{
	return questions;
}
void QuestionArray::sortDifficulty(){
	int min;
	srand(time(0));
	for (int i = 0; i < currentSize - 1; i++){
		min = i;
		for (int j = i + 1; j < currentSize; j++){
			if (questions[min]->getScore() > questions[j]->getScore()) min = j;
		}
		//moje i s makeCopy()
		Question* temp = questions[min];
		questions[min] = questions[i];
		questions[i] = temp;
	}
	int toSwap;
	for (int i = 0; i < currentSize - 1; i++){
		for (int j = i + 1; j < currentSize; j++) {
			if (questions[i]->getScore() == questions[j]->getScore()){ //we swap the questions with the same category so that the teacher can get different variant each time
				toSwap = rand() % 2;
				if (toSwap == 1){
					Question*t = questions[i];
					questions[i] = questions[j];
					questions[j] = t;
				}
			}
			else if (questions[i]->getScore() < questions[j]->getScore()) break; // i vinagi e <= j
		}
	}
}
void QuestionArray::createArray(string filename){
	ifstream reader(filename, ios::in);
	size = 10, currentSize = 0;
	questions = new Question*[size];
	int typeOfQuestion; //1-MultipleChoice, 2-OpenEnded, 3-ManyAnswers
	while (!reader.eof()){
		if (currentSize == size){
			Question**p = questions;
			questions = new Question*[size*2];
			for (int i = 0; i < currentSize; i++){
				questions[i] = p[i]; //tuk da e set
			}
			size *= 2;
		}
		string a;
		getline(reader, a);
		if (PatternValidation::validNumber(a) == 1) typeOfQuestion = stoi(a); 
		else break; 
		switch (typeOfQuestion){
		case 1:
			questions[currentSize] = new MultipleChoice();
			questions[currentSize]->readFromFile(reader);
			break;
		case 2:
		    questions[currentSize] = new OpenEndedQuestion();
			questions[currentSize]->readFromFile(reader);
			break;
		case 3:
			questions[currentSize] = new ManyAnswers();
			questions[currentSize]->readFromFile(reader);
			break;
		}
		currentSize++;
	}
	reader.close();
}
int QuestionArray::personaliseQuestionArray(string& filename, int questionsNumber, int bottom, int top, string& cat, string& fileToWriteTo, bool answers, bool category){
	QuestionArray a;
	a.createArray(filename);
	a.sortDifficulty();
	QuestionArray*personalised = new QuestionArray();
	personalised -> setSize(questionsNumber);
	personalised->questions = new Question*[personalised->size];
	int j = 0;
	for (int i = 0; i < a.currentSize; i++){
		if (j == personalised->size) break;
		if (a.questions[i]->getScore() >= bottom && a.questions[i]->getScore() <= top && a.questions[i]->getCategory() == cat){ 
			int aType = a.questions[i]->getType();
			switch (aType)
			{
			case 1:
				personalised->questions[j] = new MultipleChoice();
				personalised->questions[j] = dynamic_cast<MultipleChoice*>(a.questions[i]);
				break;
			case 2:
				personalised->questions[j] = new OpenEndedQuestion();
				personalised->questions[j] = dynamic_cast<OpenEndedQuestion*>(a.questions[i]);
				break;
			case 3:
				personalised->questions[j] = new ManyAnswers();
				personalised->questions[j] = dynamic_cast<ManyAnswers*>(a.questions[i]);
				break;
			}
			personalised->questions[j]->writeToFileForTeachers(fileToWriteTo, answers, category);
			j++;
		}
	}
	int noQ = 0;
	if (j < personalised->size && j != 0) noQ = 0;// it will cout << "There are not enough questions that match your requirements in the file you entered.";
	else if (j == 0)  noQ = 1; //cout << "There are no questions that match your reqirements in the file you entered.";
	else noQ = 2; //it won't cout anything
	return noQ;
}
