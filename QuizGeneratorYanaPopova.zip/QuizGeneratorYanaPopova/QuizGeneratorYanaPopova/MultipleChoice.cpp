#include"MultipleChoice.h"
#include<iostream>
#include<fstream>
#include<string.h>
#include<string>
using namespace std;
void MultipleChoice::setAnswerA(string answerA){
	this->answerA = answerA;
}
void MultipleChoice::setAnswerB(string answerB){
	this->answerB = answerB;
}
void MultipleChoice::setAnswerC(string answerC){
	this->answerC = answerC;
}
void MultipleChoice::setAnswerD(string answerD){
	this->answerD = answerD;
}
void MultipleChoice::setRightAnswer(char answer){
	if (answer >= 'A' && answer <= 'D') rightAnswer = answer;
}
string MultipleChoice::getAnswerA() const{
	return answerA;
}
string MultipleChoice::getAnswerB() const{
	return answerB;
}
string MultipleChoice::getAnswerC() const{
	return answerC;
}
string MultipleChoice::getAnswerD() const{
	return answerD;
}
char MultipleChoice::getRightAnswer() const{
	return rightAnswer;
}
MultipleChoice::MultipleChoice(string answerA, string answerB, string answerC, string answerD, char rightAnswer, string problem, string category, int type, int score)
	: Question(problem, category, type, score){
	setAnswerA(answerA);
	setAnswerB(answerB);
	setAnswerC(answerC);
	setAnswerD(answerD);
	setRightAnswer(rightAnswer);
}
MultipleChoice::~MultipleChoice(){}
MultipleChoice::MultipleChoice() : MultipleChoice("default a", "default b", "default c", "default d", 'A', "default p", "default cat", 1, 5){}

MultipleChoice::MultipleChoice(const MultipleChoice& m)
	: MultipleChoice(m.answerA, m.answerB, m.answerC, m.answerD, m.rightAnswer, m.getProblem(), m.getCategory(), m.getType(), m.getScore()){}

void MultipleChoice::readFromFile(ifstream& reader){
	//the pattern for this type of question is structured this way:
	//type, category, problem, answerA, answerB, answerC, answerD, rightAnswer, score
	setType(1);
	string text;
	getline(reader, text);
	setCategory(text);
	getline(reader, text);
	setProblem(text);
	getline(reader, answerA);
	getline(reader, answerB);
	getline(reader, answerC);
	getline(reader, answerD);
	char x;
	reader >> x;
	setRightAnswer(x);
	int y;
	reader >> y;
	setScore(y);
	reader.ignore(); //posle chte chete string za tipa na sledvashtiq vupros
}
void MultipleChoice::writeToFileForTeachers(string filename, bool wantTheAnswers, bool file){
	ofstream writer;
	writer.open(filename, ios::app);
	if (file == 1) {
		writer << getType() << endl;
		writer << getCategory() << endl;
	}
	writer << getProblem() << endl;
	writer << answerA << endl;
	writer << answerB << endl;
	writer << answerC << endl;
	writer << answerD << endl;
	if (file == 1) {
		writer << rightAnswer << endl;
		writer << getScore() << endl;
	}
	else{
		if (wantTheAnswers == true) writer << "Right answer: " << rightAnswer << endl;
		writer << getScore() << " points" << endl << endl;
	}
	writer.close();
}
string MultipleChoice::createAQuestion(string enteredText, int& questionSlide){
	string a;
	questionSlide++;
	if (questionSlide == 0 || questionSlide == 1 || questionSlide == 2){
		a = createBasicQuestion(enteredText, questionSlide); //we don't have to delete or set a because we create it everytime before the if-s 
		return a;
	}
	else if (questionSlide == 3){
		enteredText[0] = toupper(enteredText[0]);
		enteredText = "A. " + enteredText;
		setAnswerA(enteredText);
		a = "Answer B:";
		return a;
	}
	else if (questionSlide == 4){
		enteredText[0] = toupper(enteredText[0]);
		enteredText = "B. " + enteredText;
		setAnswerB(enteredText);
		a = "Answer C:";
		return a;
	}
	else if (questionSlide == 5){
		enteredText[0] = toupper(enteredText[0]);
		enteredText = "C. " + enteredText;
		setAnswerC(enteredText);
		a = "Answer D:";
		return a;
	}
	else if (questionSlide == 6){
		enteredText[0] = toupper(enteredText[0]);
		enteredText = "D. " + enteredText;
		setAnswerD(enteredText);
		a = "Correct answer:";
		return a;
	}
	else { //if (questionSlide == 7){
		enteredText[0] = toupper(enteredText[0]);
		setRightAnswer(enteredText[0]);
		a = "Press enter to submit the question,\nplease.";
		//nishto nqma da submit-va ha-ha
		return a;
	}
}