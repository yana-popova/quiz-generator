#pragma once
#include <iostream>
#include <fstream>
#include "MultipleChoice.h"
#include "Question.h"
#include "OpenEndedQuestion.h"
#include "ManyAnswers.h"
using namespace std;
class QuestionArray{
private:
	Question** questions = nullptr;
	int size, currentSize;
public:
	void setSize(int);
	int getSize() const;
	Question** getQuestions() const;
	void setCurrentSize(int);
	QuestionArray();
	~QuestionArray();
	void createArray(string); //this will be only for convenience - it will read all the questions from a file
	void sortDifficulty();
	int personaliseQuestionArray(string&, int, int, int, string&, string&, bool, bool); 
	//it will write to a file an array according to the teacher's preferences - they enter the category, the difficulty interval, choose the type of questions 
};