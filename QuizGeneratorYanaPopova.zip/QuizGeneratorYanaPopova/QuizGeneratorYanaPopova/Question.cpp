#include<iostream>
#include<fstream>
#include<string.h>
#include"Question.h"
#include"PatternValidation.h"
#include <SFML/Graphics.hpp>
using namespace std;
void Question::setProblem(string problem){
	this->problem = problem;
}
void Question::setCategory(string category) {
	this->category = category;
}
void Question::setType(int type){
	this->type = type;
}
void Question::setScore(int score) {
	this->score = score;
}
string Question::getProblem() const{
	return problem;
}
string Question::getCategory() const{
	return category;
}
int Question::getType() const{
	return type;
}
int Question::getScore() const {
	return score;
}
Question::Question(string problem, string category, int type, int score){
	setProblem(problem);
	setCategory(category);
	setType(type);
	setScore(score);
}
Question::Question() : Question("default problem", "default category", 0, 0){}
Question::Question(const Question& q) : Question(q.problem, q.category, q.type, q.score){}
Question::~Question(){}
string Question::createBasicQuestion(string enteredText, int& questionSlide){
	string toReturn;
	if (questionSlide == 0){
		enteredText[0] = toupper(enteredText[0]);
		setCategory(enteredText);
		toReturn = "Problem:";
		return toReturn;
	}
	else if (questionSlide == 1){
		enteredText[0] = toupper(enteredText[0]);
		setProblem(enteredText);
		toReturn = "Difficulty:";
		return toReturn;
	}
	else { //questionSlide=2
		bool validNumber = PatternValidation::validNumber(enteredText);
		if (validNumber == 0){
			questionSlide--;
			toReturn = "Invalid format. It should be a\nwhole number. Try again.";
		}
		else {
			score = stoi(enteredText);
		}
		switch (type){
		case 1:
			toReturn = "Answer A (you do not need to write\nthe letter of the option):";
			break;
		case 2:
			toReturn = "Right answer (it should be a decimal):";
			break;
		case 3:
			toReturn = "Please use capital letters for the \nanswers and separate them with spaces:";
			break;
		}
		return toReturn;
	}
}


