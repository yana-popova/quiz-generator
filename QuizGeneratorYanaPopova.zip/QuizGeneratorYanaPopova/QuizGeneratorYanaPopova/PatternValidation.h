#pragma once
#include<string>
using namespace std;
class PatternValidation{
public:
	static bool doesTheFileExist(string);
	static bool validFileFormat(string);
	static bool validMultipleChoiceAnswerFromat(string);
	static bool validCategoryFormat(string);
	static bool validNumber(string);
	static bool validDouble(string);
};