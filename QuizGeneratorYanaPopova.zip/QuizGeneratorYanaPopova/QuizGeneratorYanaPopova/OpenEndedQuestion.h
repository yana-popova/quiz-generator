#pragma once
#include"Question.h"
using namespace std;
class OpenEndedQuestion : public Question{
private:
	double rightAnswer;
public:
	void setRightAnswer(double);
	double getRightAnswer() const;
	OpenEndedQuestion();
	OpenEndedQuestion(string, string, double, int, int); //we need this for the default constructor
	OpenEndedQuestion(const OpenEndedQuestion&);
	~OpenEndedQuestion(); //it will be empty

	void readFromFile(ifstream&);
	void writeToFileForTeachers(string, bool, bool);
	string createAQuestion(string, int&);
};
