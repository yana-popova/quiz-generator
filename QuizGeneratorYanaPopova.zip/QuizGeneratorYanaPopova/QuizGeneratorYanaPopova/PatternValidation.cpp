#include"PatternValidation.h"
#include<string>
#include<fstream>
#include<iostream>
#include<regex>
using namespace std;
bool PatternValidation::doesTheFileExist(string filename){
	ifstream str(filename.c_str());
	bool doesItExist = str.good();
	return doesItExist;
}
bool PatternValidation::validFileFormat(string filename){
	regex expression(".+[.]txt"); //checks whether the name of the file is xxxxxxx.txt
	if (regex_match(filename, expression) == 1) return true;
	return false;
}
bool PatternValidation::validMultipleChoiceAnswerFromat(string answers){
	regex expressionFirst("(([A-Z][ ])+[A-Z])"); //checks whether the answer string is "X X X"
	regex expressionSecond("[A-Z]{1}");
	if (regex_match(answers, expressionFirst) == 1 || regex_match(answers, expressionSecond) == 1) return true;
	return false;
}
bool PatternValidation::validCategoryFormat(string cat){
	regex expression("[A-Z]{1}[a-z]+"); //checks whether the category starts with a capital letter 
	if (regex_match(cat, expression) == 1) return true;
	return false;
}
bool PatternValidation::validNumber(string num){
	regex expression("[0-9]+"); //checks whether it is a whole positive number
	if (regex_match(num, expression) == 1) return true;
	return false;
}
bool PatternValidation::validDouble(string num){
	regex expression("[-0-9]+[.][0-9]+"); 
	if (regex_match(num, expression) == 1) return true;
	return false;
}