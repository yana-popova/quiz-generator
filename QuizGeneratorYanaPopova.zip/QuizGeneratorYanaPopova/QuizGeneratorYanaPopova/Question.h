#pragma once 
#include<fstream>
#include<string.h>
using namespace std;
class Question{
private:
	string problem;
	string category;
	int type;
	int score;
public:
	void setProblem(string);
	void setCategory(string);
	void setType(int);
	void setScore(int);
	string getProblem() const;
	string getCategory() const;
	int getType() const;
	int getScore() const;
	Question();
	Question(string, string, int, int);
	Question(const Question&);
	virtual ~Question();

	string createBasicQuestion(string, int&); //this will create the fields of Question and in createAQuestion will be entered the fields of the inherited class
	virtual string createAQuestion(string, int&) = 0; //this function will be continued in the heir class
	virtual void readFromFile(ifstream&) = 0;
	virtual void writeToFileForTeachers(string, bool, bool) = 0;
};