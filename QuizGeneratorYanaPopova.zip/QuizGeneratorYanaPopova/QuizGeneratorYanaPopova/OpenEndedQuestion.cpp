#include"OpenEndedQuestion.h"
#include"PatternValidation.h"
#include<iostream>
#include<fstream>
#include<string>
using namespace std;
void OpenEndedQuestion::setRightAnswer(double rightAnswer){
	this->rightAnswer = rightAnswer;
}
double OpenEndedQuestion::getRightAnswer() const{
	return rightAnswer;
}
OpenEndedQuestion::OpenEndedQuestion(string category, string problem, double rightAnswer, int type, int score){
	setCategory(category);
	setProblem(problem);
	setRightAnswer(rightAnswer);
	setType(type);
	setScore(score);
}
OpenEndedQuestion::OpenEndedQuestion() : OpenEndedQuestion("default category", "default problem", 0, 2, 10){}
OpenEndedQuestion::OpenEndedQuestion(const OpenEndedQuestion& n) : OpenEndedQuestion(n.getCategory(), n.getProblem(), n.rightAnswer, n.getType(), n.getScore()){}
OpenEndedQuestion::~OpenEndedQuestion(){}
void OpenEndedQuestion::readFromFile(ifstream& reader){
	setType(2);
	string text;
	getline(reader, text);
	setCategory(text);
	getline(reader, text);
	setProblem(text);
	double ans;
	reader >> ans;
	setRightAnswer(ans);
	int sc;
	reader >> sc;
	setScore(sc);
	reader.ignore(); // posle chte chete string za tipa na vuprosa
}
void OpenEndedQuestion::writeToFileForTeachers(string filename, bool wantTheAnswers, bool file){
	ofstream writer;
	writer.open(filename, ios::app);
	if (file == 1) {
		writer << getType() << endl;
		writer << getCategory() << endl;
	}
	writer << getProblem() << endl;
	if (file == 1){
		writer << rightAnswer << endl << getScore() << endl;
	}
	else{
		if (wantTheAnswers) writer << "Right answer: " << rightAnswer << endl;
		else writer << "Answer:______" << endl;
		writer << getScore() << " points" << endl << endl;
	}
	writer.close();
}
string OpenEndedQuestion::createAQuestion(string enteredText, int&questionSlide){
	string a;
	questionSlide++;
	if (questionSlide == 0 || questionSlide == 1 || questionSlide == 2){
		a = createBasicQuestion(enteredText, questionSlide); //we don't have to delete or set a because we create it everytime before the if-s 
		return a;
	}
	else {//if (questionSlide == 3){
		bool validDouble = PatternValidation::validDouble(enteredText);
		if (validDouble == 0){
			questionSlide--;
			a = "Invalid format. It should be a\ndecimal. Try again.";
		}
		else {
			rightAnswer = stod(enteredText);
			a = "Press enter to submit the question,\nplease.";
		}
		return a;
	}
}