#pragma once
#include"Question.h"
#include<iostream>
#include<fstream>
using namespace std;
class ManyAnswers : public Question{
private:
	string*options = nullptr;
	string correctAnswers; //format - A B D F
	int sizeOptions;
public:
	string* getOptions() const;
	void setCorrectAnswers(string);
	string getCorrectAnswers() const;
	void setSizeOptions(int);
	int getSizeOptions() const;
	ManyAnswers();
	ManyAnswers(string*, string, int, string, string, int, int);
	~ManyAnswers();

	void readFromFile(ifstream&);
	void writeToFileForTeachers(string, bool, bool);
	string createAQuestion(string, int&);
};